  @include('backend/includes/partials/sidebar')

        <!-- top navigation -->
  @include('backend/includes/partials/header')
        
        <!-- /top navigation -->

        <!-- page content -->
          @yield('content')
        <!-- /page content -->
  @include('backend/includes/partials/footer')

        <!-- footer content -->
        
