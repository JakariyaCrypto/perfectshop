<?php

namespace App\Http\Controllers\backend\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GenreralAdminController extends Controller
{
    public function index(){
        return "general-admin";
    }
}
