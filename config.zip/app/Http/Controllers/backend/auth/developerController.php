<?php

namespace App\Http\Controllers\backend\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class developerController extends Controller
{
   public function index(){
        return "developer";
    }
}
